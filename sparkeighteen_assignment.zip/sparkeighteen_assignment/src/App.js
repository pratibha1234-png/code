import React from 'react';
import './App.css';
import Comp from  './Comp';

class App extends React.Component{
  render(){
    return (
      <div>
        <Comp />
      </div>
    );
  }
}
export default App;
