import React from 'react';
import './subheading.css';

class Subheading1 extends  React.Component{
constructor(props){
  super(props);
   this.state = {
     item:true
  }
  this.handleDelete1=this.handleDelete1.bind(this);
}

    handleDelete1 = () =>{
      alert()
      this.setState({
    item: false
   });
      }

render(){
  console.log(this.props.data1)
  return(

          <div>

       {

         this.state.item===false

       ?
       null
       :

       <p className="ItemDesign"
         item={this.state.item}>
         {this.props.data1} &nbsp; &nbsp; 
         <span className="spanDelete"
          onClick={this.props.handleDelete1}>
          X
          </span>
          </p>


     }

          </div>
      )
}

}

export default Subheading1;
