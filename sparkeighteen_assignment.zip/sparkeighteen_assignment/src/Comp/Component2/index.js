import React from 'react';
import Subheading1 from './Subheading1';
import Subheading2 from './Subheading2';
import Subheading3 from './Subheading3';
import Subheading4 from './Subheading4';
import Subheading5 from './Subheading5';
import Subheading6 from './Subheading6';

class Component2 extends  React.Component{
render(){

  let abc1= this.props.result1
  let abc2= this.props.result2
  let abc3= this.props.result3
  let abc4= this.props.result4
  let abc5= this.props.result5
  let abc6= this.props.result6
  let heading1=this.props.heading1
  let heading2=this.props.heading2
  let heading3=this.props.heading3
  let checked1=this.props.checked1
  let checked2=this.props.checked2
  let checked3=this.props.checked3
  let checked4=this.props.checked4
  let checked5=this.props.checked5
  let checked6=this.props.checked6
  return(

          <div>
          <div className="some-container">

          {
             (() => {
                           if (checked1===true && checked2===true)
                              return <h2>{heading1}</h2>
                               if (checked1===true && checked2===false)
                               return <h2>{heading1}</h2>
                               if (checked1===false && checked2===true)
                               return <h2>{heading1}</h2>
                               if (checked1===false && checked2===false)
                               return null
                           else
                              return <span></span>
                     })()
          }



          {
        this.props.checked1===true
        ?
        <Subheading1
        data1={abc1}
        handleDelete1={this.props.handleDelete1}
        />
        :
        null
        }


              {
                this.props.checked2===true
                  ?
                  <Subheading2
                  data2={abc2}
                 handleDelete2={this.props.handleDelete2}
                  />
                  :
               null
        }

          {
             (() => {
                 if (checked3===true && checked4===true)
                    return <h2>{heading2}</h2>
                     if (checked3===true && checked4===false)
                     return <h2>{heading2}</h2>
                     if (checked3===false && checked4===true)
                     return <h2>{heading2}</h2>
                     if (checked3===false && checked4===false)
                     return null
                 else
                    return <span></span>
             })()
          }

          </div>

                  {
                        this.props.checked3===true
                        ?
                        <Subheading3
                        data3={abc3}
                       handleDelete3={this.props.handleDelete3}
                        />
                              :
                        null
                  }



              {
                  this.props.checked4===true
                  ?
                  <Subheading4
                  data4={abc4}
                  handleDelete4={this.props.handleDelete4}
                  />
                        :
                     null
                }


                {
                   (() => {
                       if (checked5===true && checked6===true)
                          return <h2>{heading3}</h2>
                           if (checked5===true && checked6===false)
                           return <h2>{heading3}</h2>
                           if (checked5===false && checked6===true)
                           return <h2>{heading3}</h2>
                           if (checked5===false && checked6===false)
                           return null
                       else
                          return <span></span>
                   })()
                }


                {
                      this.props.checked5===true
                          ?
                          <Subheading5
                          data5={abc5}
                        handleDelete5={this.props.handleDelete5}
                          />
                          :
                     null
                  }




                  {
                        this.props.checked6===true
                            ?
                            <Subheading6
                            data6={abc6}
                           handleDelete6={this.props.handleDelete6}
                            />
                            :
                       null
                    }


          </div>
      )
}

}

export default Component2;
