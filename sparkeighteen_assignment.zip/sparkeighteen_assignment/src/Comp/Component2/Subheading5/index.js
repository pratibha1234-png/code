import React from 'react';
import './subheading.css';

class Subheading5 extends  React.Component{
constructor(props){
  super(props);
   this.state = {
     item:true
  }
  this.handleDelete=this.handleDelete.bind(this);
}

    handleDelete = (event) =>{
      this.setState({
    item: false
   });
      }

render(){

  return(

          <div>

       {

         this.state.item===false

       ?
       null
       :

       <p className="ItemDesign"  item={this.state.item}>{this.props.data5}&nbsp; &nbsp; <span className="spanDelete" onClick={this.props.handleDelete5}>X</span></p>


     }


          </div>
      )
}

}

export default Subheading5;
