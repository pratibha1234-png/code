import React from 'react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

class Component1 extends  React.Component{


isValueChecked1 = e => {

  this.props.isValueChecked1(e.target.name);


}


isValueChecked2 = e => {

this.props.isValueChecked2(e.target.name);


}


isValueChecked3 = e => {

this.props.isValueChecked3(e.target.name);


}


isValueChecked4 = e => {

this.props.isValueChecked4(e.target.name);


}

isValueChecked5 = e => {

this.props.isValueChecked5(e.target.name);


}


isValueChecked6 = e => {

this.props.isValueChecked6(e.target.name);


}

render(){
  console.log(this.props.checked1)
  return(

          <div>
<form>
<h2>{this.props.heading1}</h2>
<FormControlLabel
      control={
        <Checkbox
          name="Aasiya Jayavant"
          color="primary"
          checked={this.props.checked1}
          onChange={this.isValueChecked1}
          value="value1"
        />
      }
      label="Aasiya Jayavant"
      />

<br/>

<FormControlLabel
      control={
        <Checkbox
          name="Luvleen Lawrence"
          color="primary"
          checked={this.props.checked2}
          onChange={this.isValueChecked2}
          value="value2"
        />
      }
      label="Luvleen Lawrence"
      />

      <br/>

                  </form>



                  <form >
                  <h2>{this.props.heading2}</h2>
                  <FormControlLabel
                        control={
                          <Checkbox
                            name="Deveedaas Nandi"
                            color="primary"
                            checked={this.props.checked3}
                            onChange={this.isValueChecked3}
                            value="value3"
                          />
                        }
                        label="Deveedaas Nandi"
                        />

                  <br/>

                  <FormControlLabel
                        control={
                          <Checkbox
                            name="Obasey Chidy"
                            color="primary"
                            checked={this.props.checked4}
                            onChange={this.isValueChecked4}
                            value="value4"
                          />
                        }
                        label="Obasey Chidy"
                        />

                        <br/>


                                    </form>



                                    <form >
                                    <h2>{this.props.heading3}</h2>
                                    <FormControlLabel
                                          control={
                                            <Checkbox
                                              name="Aaroan Almaraz"
                                              color="primary"
                                              checked={this.props.checked5}
                                              onChange={this.isValueChecked5}
                                              value="value5"
                                            />
                                          }
                                          label="Aaroan Almaraz"
                                          />

                                    <br/>

                                    <FormControlLabel
                                          control={
                                            <Checkbox
                                              name="Jelena Denisova"
                                              color="primary"
                                              checked={this.props.checked6}
                                              onChange={this.isValueChecked6}
                                              value="value6"
                                            />
                                          }
                                          label="Jelena Denisova"
                                          />

                                          <br/>


                                                      </form>
          </div>
      )
}

}

export default Component1;
