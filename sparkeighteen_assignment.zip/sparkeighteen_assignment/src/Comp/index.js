import React from 'react';
import Header from './Header';
import Component1 from './Component1';
import Component2 from './Component2';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

class Comp extends  React.Component{
  constructor(props){
    super(props)
      this.state={
        result1:'',
        result2:'',
        result3:'',
        result4:'',
        result5:'',
        result6:'',
        checked1:false,
        checked2:false,
        checked3:false,
        checked4:false,
        checked5:false,
        checked6:false,
        heading1:"Portugal",
        heading2:"Nicaragua",
        heading3:"Marshall Island"
      }
      this.handleDelete1 = this.handleDelete1.bind(this);
      this.handleDelete2 = this.handleDelete2.bind(this);
      this.handleDelete3 = this.handleDelete3.bind(this);
      this.handleDelete4 = this.handleDelete4.bind(this);
      this.handleDelete5 = this.handleDelete5.bind(this);
       this.handleDelete6 = this.handleDelete6.bind(this);

}


  isValueChecked1 = (checkedValue1) => {
  //  console.log(props);
  this.setState({
   result1:checkedValue1,
   checked1: !this.state.checked1,
   heading1: this.state.heading1
 })

console.log(this.state.checked1);
  }

  isValueChecked2 = checkedValue2 => {

  this.setState({

  result2:checkedValue2,
  checked2: !this.state.checked2,
     heading1: this.state.heading1
  })

  console.log(this.state.checked2);

  }

  isValueChecked3 = checkedValue3 => {

  this.setState({

  result3:checkedValue3,
  checked3: !this.state.checked3,
     heading2: this.state.heading2
  })

  }


  isValueChecked4 = checkedValue4 => {

  this.setState({

  result4:checkedValue4,
  checked4: !this.state.checked4,
  heading2: this.state.heading2
  })

  }


  isValueChecked5 = checkedValue5 => {

  this.setState({

  result5:checkedValue5,
  checked5: !this.state.checked5,
    heading3: this.state.heading3
  })

  }


  isValueChecked6 = checkedValue6 => {

  this.setState({

  result6:checkedValue6,
  checked6: !this.state.checked6,
  heading3: this.state.heading3
  })

  }


  handleDelete1(){
console.log(this.state.checked1)
console.log("handledelete is clicked")
this.setState({
  checked1 : false
});


console.log(this.state.checked1)

}

handleDelete2(){

this.setState({
checked2 : false
});

}


handleDelete3(){

this.setState({
checked3 : false,
});

}

handleDelete4(){

this.setState({
checked4 : false,
});

}

handleDelete5(){

this.setState({
checked5 : false,
});

}

handleDelete6(){

this.setState({
checked6 : false,
});

}

render(){

  return(

          <div>

          <Header />
          <br/>
          <Grid container spacing={3}>
           <Grid item xs={2}></Grid>
                 <Grid item xs={4}>
                   <Paper  style={{flex:'1', padding: '1em', border: '1px solid'}}>

                            <Component1
                                isValueChecked1={this.isValueChecked1}
                                isValueChecked2={this.isValueChecked2}
                                isValueChecked3={this.isValueChecked3}
                                isValueChecked4={this.isValueChecked4}
                                isValueChecked5={this.isValueChecked5}
                                isValueChecked6={this.isValueChecked6}
                                heading1={this.state.heading1}
                                heading2={this.state.heading2}
                                heading3={this.state.heading3}

                             checked1={this.state.checked1}
                             checked2={this.state.checked2}
                             checked3={this.state.checked3}
                             checked4={this.state.checked4}
                             checked5={this.state.checked5}
                             checked6={this.state.checked6}
                            />



                   </Paper>
                 </Grid>

                 <Grid item xs={4}>
                   <Paper style={{flex:"1", padding: '1em', border: '1px solid',height:'94%', paddingTop:'inherit'}}>
                        <Component2
                        result1={this.state.result1}
                        result2={this.state.result2}
                        result3={this.state.result3}
                        result4={this.state.result4}
                        result5={this.state.result5}
                        result6={this.state.result6}
                          checked1={this.state.checked1}
                          checked2={this.state.checked2}
                          checked3={this.state.checked3}
                          checked4={this.state.checked4}
                          checked5={this.state.checked5}
                          checked6={this.state.checked6}
                          handleDelete1={this.handleDelete1}
                          handleDelete2={this.handleDelete2}
                          handleDelete3={this.handleDelete3}
                          handleDelete4={this.handleDelete4}
                          handleDelete5={this.handleDelete5}
                          handleDelete6={this.handleDelete6}
                          heading1={this.state.heading1}
                          heading2={this.state.heading2}
                          heading3={this.state.heading3}
                    />
                   </Paper>
                 </Grid>
                 <Grid item xs={2}></Grid>
          </Grid>

          </div>
      )

}


}

export default Comp;
