import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import './header.css';

class Header extends React.Component{

render(){
return(

<div>

      <AppBar position="static" style={{backgroundColor:'#fff'}}>
        <Toolbar>
        <Typography variant="h6" style={{color:"purple"}} >
            LOGO
          </Typography>

          <div className="navbar">
                <a href="#home">Home</a>
                <a href="#news">MyPortfolio</a>
                <a href="#contact">Clients</a>
                <Button variant="contained" color="cream">
                    Get in Touch
                </Button>
          </div>
        </Toolbar>
      </AppBar>


</div>

)

}
}

export default Header;
